@echo off
chcp 65001 >nul

echo [HAKQM] Launch Cover GUI
echo Base: %~dp0
echo.

if not exist "%~dp0app" (
    echo [ERROR] app folder not found.
    echo %~dp0app
    pause
    exit /b 1
)

if not exist "%~dp0app\.venv\Scripts\python.exe" (
    echo [ERROR] Python virtual environment not found.
    echo %~dp0app\.venv\Scripts\python.exe
    pause
    exit /b 1
)

if not exist "%~dp0app\gui_issue_cover.py" (
    echo [ERROR] gui_issue_cover.py not found.
    echo %~dp0app\gui_issue_cover.py
    pause
    exit /b 1
)

if not exist "%~dp0app\templates\Test_Report_Cover.xls" (
    echo [ERROR] Test_Report_Cover.xls not found.
    echo %~dp0app\templates\Test_Report_Cover.xls
    pause
    exit /b 1
)

cd /d "%~dp0app"
".venv\Scripts\python.exe" "gui_issue_cover.py"

if errorlevel 1 (
    echo.
    echo [ERROR] Cover GUI failed to run.
    pause
    exit /b 1
)