@echo off
chcp 65001 >nul

cd /d "%~dp0app"

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" health_check.py
) else (
    python health_check.py
)

echo.
echo ================================
echo Health check finished.
echo ================================
pause