@echo off
chcp 65001 >nul

cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" gui_issue_cover.py
) else (
    python gui_issue_cover.py
)

echo.
echo ================================
echo Cover issue program finished.
echo ================================
pause