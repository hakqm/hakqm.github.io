import logging
from typing import Optional

import cv2
import fitz  # PyMuPDF
import numpy as np

logger = logging.getLogger("HAKQM")


def _page_to_cv2(page, scale: float):
    """Convert a PyMuPDF page to an OpenCV image at the given scale."""
    mat = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=mat)
    img_data = pix.tobytes("png")
    nparr = np.frombuffer(img_data, np.uint8)
    return cv2.imdecode(nparr, cv2.IMREAD_COLOR)


def _detect_qr(img) -> str:
    """Run QRCodeDetector on color then grayscale. Returns data string or ''."""
    detector = cv2.QRCodeDetector()

    data, _, _ = detector.detectAndDecode(img)
    if data:
        return data

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    data, _, _ = detector.detectAndDecode(gray)
    return data if data else ""


def _scan_page(page) -> Optional[str]:
    """Try multiple render scales to detect a QR code on one page."""
    for scale in (2.0, 3.0, 1.5):
        img = _page_to_cv2(page, scale)
        data = _detect_qr(img)
        if data:
            return data
    return None


def read_qr_from_pdf(pdf_path: str, qr_prefix: str) -> dict:
    """
    Scan PDF for a QR code that starts with qr_prefix.
    Strategy: try page 2 first, then remaining pages.

    Returns a dict with keys:
      status : 'found' | 'other_qr' | 'no_qr' | 'error'
      data   : QR string (only when status == 'found')
      page   : 1-based page number (only when status == 'found')
      error  : exception message (only when status == 'error')
    """
    try:
        doc = fitz.open(pdf_path)
        total = len(doc)

        # Build scan order: page index 1 first, then the rest
        indices = [1] if total >= 2 else []
        indices += [i for i in range(total) if i != 1]

        any_qr_found = False

        for idx in indices:
            data = _scan_page(doc[idx])
            if not data:
                continue
            if data.startswith(qr_prefix):
                doc.close()
                return {"status": "found", "data": data, "page": idx + 1}
            any_qr_found = True

        doc.close()

        if any_qr_found:
            return {"status": "other_qr", "data": None, "page": None}
        return {"status": "no_qr", "data": None, "page": None}

    except Exception as exc:
        logger.error(f"QR 읽기 오류 ({pdf_path}): {exc}")
        return {"status": "error", "data": None, "page": None, "error": str(exc)}
