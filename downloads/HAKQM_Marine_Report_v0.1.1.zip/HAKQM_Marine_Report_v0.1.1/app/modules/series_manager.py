import os
import re
from typing import Optional

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

SHEET_NAME = "시리즈관리"
COLUMNS = ["고객사", "시리즈ID", "폴더표시명", "현재폴더명", "포함호선", "사용여부", "비고"]
COL_WIDTHS = [16, 20, 30, 30, 50, 10, 20]

_WIN_INVALID = re.compile(r'[\\/:*?"<>|]')


def sanitize_folder_name(name: str) -> str:
    """Remove Windows-invalid path chars; preserve , and ~."""
    return _WIN_INVALID.sub("_", name).strip()


def _write_headers(ws):
    font = Font(bold=True, color="FFFFFF")
    fill = PatternFill(fill_type="solid", fgColor="2F5496")
    align = Alignment(horizontal="center", vertical="center")
    for col, (header, width) in enumerate(zip(COLUMNS, COL_WIDTHS), 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = font
        cell.fill = fill
        cell.alignment = align
        ws.column_dimensions[cell.column_letter].width = width
    ws.row_dimensions[1].height = 20
    ws.freeze_panes = "A2"


def _ensure_excel(excel_path: str):
    if not os.path.exists(excel_path):
        os.makedirs(os.path.dirname(excel_path), exist_ok=True)
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = SHEET_NAME
        _write_headers(ws)
        wb.save(excel_path)
        print(f"[시리즈관리] 기본 양식 생성: {excel_path}")


def _load(excel_path: str):
    _ensure_excel(excel_path)
    wb = openpyxl.load_workbook(excel_path)
    ws = wb[SHEET_NAME] if SHEET_NAME in wb.sheetnames else wb.active
    return wb, ws


def _col_map(ws) -> dict:
    return {ws.cell(1, c).value: c for c in range(1, ws.max_column + 1) if ws.cell(1, c).value}


def get_series_info(excel_path: str, customer: str, series_id: str) -> Optional[dict]:
    """
    Return {"display_name": ..., "current_folder_name": ...} for matching row.
    Conditions: customer match, series_id match, 사용여부 == Y.
    Returns None if not found or excel_path is empty.
    """
    if not excel_path:
        return None
    try:
        wb, ws = _load(excel_path)
        ci = _col_map(ws)
        required = ["고객사", "시리즈ID", "폴더표시명", "현재폴더명", "사용여부"]
        missing = [k for k in required if k not in ci]
        if missing:
            print(f"[시리즈관리] 컬럼 누락: {missing}")
            return None

        for row in ws.iter_rows(min_row=2, values_only=True):
            r_customer = str(row[ci["고객사"] - 1] or "").strip()
            r_series_id = str(row[ci["시리즈ID"] - 1] or "").strip()
            r_active = str(row[ci["사용여부"] - 1] or "").strip().upper()
            if r_customer != customer or r_series_id != series_id or r_active != "Y":
                continue

            display_name = sanitize_folder_name(str(row[ci["폴더표시명"] - 1] or "").strip())
            current_name = sanitize_folder_name(str(row[ci["현재폴더명"] - 1] or "").strip())
            if not current_name:
                current_name = display_name

            return {"display_name": display_name, "current_folder_name": current_name}

        return None
    except Exception as exc:
        print(f"[시리즈관리] 조회 오류: {exc}")
        return None


def update_current_folder(excel_path: str, customer: str, series_id: str, new_name: str) -> bool:
    """Update 현재폴더명 after successful folder rename. Returns True on success."""
    if not excel_path:
        return False
    try:
        wb, ws = _load(excel_path)
        ci = _col_map(ws)
        for row_idx in range(2, ws.max_row + 1):
            r_customer = str(ws.cell(row_idx, ci["고객사"]).value or "").strip()
            r_series_id = str(ws.cell(row_idx, ci["시리즈ID"]).value or "").strip()
            r_active = str(ws.cell(row_idx, ci["사용여부"]).value or "").strip().upper()
            if r_customer == customer and r_series_id == series_id and r_active == "Y":
                ws.cell(row_idx, ci["현재폴더명"]).value = new_name
                try:
                    wb.save(excel_path)
                except PermissionError:
                    print(
                        "[시리즈관리] 검사현황.xlsx 또는 시리즈관리.xlsx가 열려 있을 수 있습니다. "
                        "파일을 닫고 다시 실행하세요."
                    )
                    return False
                return True
        return False
    except Exception as exc:
        print(f"[시리즈관리] 현재폴더명 업데이트 오류: {exc}")
        return False
