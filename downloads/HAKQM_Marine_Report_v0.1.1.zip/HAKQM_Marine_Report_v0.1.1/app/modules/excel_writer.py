import os
from datetime import datetime

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

SHEET_NAME = "검사현황"
HEADERS = [
    "처리일시", "Report ID", "고객사", "시리즈ID", "시리즈폴더명",
    "호선", "시리즈", "품목", "품목코드", "상태", "저장경로", "원본파일명", "비고",
]
COL_WIDTHS = [20, 22, 14, 18, 28, 8, 16, 8, 14, 12, 60, 40, 30]


def _apply_header_cell(ws, col: int, value: str, width: float):
    cell = ws.cell(row=1, column=col, value=value)
    cell.font = Font(bold=True, color="FFFFFF")
    cell.fill = PatternFill(fill_type="solid", fgColor="2F5496")
    cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.column_dimensions[get_column_letter(col)].width = width


def _write_headers(ws):
    for col, (header, width) in enumerate(zip(HEADERS, COL_WIDTHS), 1):
        _apply_header_cell(ws, col, header, width)
    ws.row_dimensions[1].height = 20
    ws.freeze_panes = "A2"


def _migrate_if_needed(ws):
    """기존 11컬럼 포맷에 시리즈ID·시리즈폴더명 컬럼을 col 4·5에 삽입."""
    if ws.max_row < 1:
        return
    existing = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    if "시리즈ID" in existing:
        return
    ws.insert_cols(4, 2)
    _apply_header_cell(ws, 4, "시리즈ID", 18)
    _apply_header_cell(ws, 5, "시리즈폴더명", 28)


def _get_or_create_workbook(excel_path: str):
    os.makedirs(os.path.dirname(excel_path), exist_ok=True)
    if os.path.exists(excel_path):
        wb = openpyxl.load_workbook(excel_path)
        ws = wb[SHEET_NAME] if SHEET_NAME in wb.sheetnames else wb.active
        _migrate_if_needed(ws)
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = SHEET_NAME
        _write_headers(ws)
    return wb, ws


def append_record(excel_path: str, record: dict):
    """Append one processing result row to the master Excel file."""
    wb, ws = _get_or_create_workbook(excel_path)

    if ws.max_row == 0 or ws.cell(1, 1).value != HEADERS[0]:
        ws.insert_rows(1)
        _write_headers(ws)

    next_row = ws.max_row + 1
    values = [
        record.get("처리일시", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        record.get("report_id", ""),
        record.get("customer", ""),
        record.get("series_id", ""),
        record.get("series_folder", ""),
        record.get("hull_no", ""),
        record.get("series", ""),
        record.get("item_type", ""),
        record.get("item_code", ""),
        record.get("상태", ""),
        record.get("저장경로", ""),
        record.get("원본파일명", ""),
        record.get("비고", ""),
    ]

    for col, value in enumerate(values, 1):
        cell = ws.cell(row=next_row, column=col, value=value)
        cell.alignment = Alignment(vertical="center")

    try:
        wb.save(excel_path)
    except PermissionError:
        raise PermissionError(
            "검사현황.xlsx 또는 시리즈관리.xlsx가 열려 있을 수 있습니다. "
            "파일을 닫고 다시 실행하세요."
        )
