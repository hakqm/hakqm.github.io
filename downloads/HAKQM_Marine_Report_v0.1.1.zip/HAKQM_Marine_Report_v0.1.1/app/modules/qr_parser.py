from typing import Optional


def parse_qr_data(qr_string: str) -> Optional[dict]:
    """
    V1: HAKQM_TR|report_id|customer|hull_no|item_type|item_code
    V3: HAKQM_TR_V3|report_id|customer|series_id|hull_no|item_type|item_code
    """
    parts = qr_string.strip().split("|")
    prefix = parts[0] if parts else ""

    if prefix == "HAKQM_TR_V3" and len(parts) == 7:
        return {
            "qr_version": "V3",
            "system": parts[0],
            "report_id": parts[1],
            "customer": parts[2],
            "series_id": parts[3],
            "hull_no": parts[4],
            "item_type": parts[5],
            "item_code": parts[6],
        }

    if prefix == "HAKQM_TR" and len(parts) == 6:
        return {
            "qr_version": "V1",
            "system": parts[0],
            "report_id": parts[1],
            "customer": parts[2],
            "series_id": None,
            "hull_no": parts[3],
            "item_type": parts[4],
            "item_code": parts[5],
        }

    return None
