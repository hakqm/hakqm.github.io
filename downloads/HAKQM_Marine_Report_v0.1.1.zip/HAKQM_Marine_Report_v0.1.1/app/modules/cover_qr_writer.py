import os


def _get_unique_path(base_path: str) -> str:
    if not os.path.exists(base_path):
        return base_path
    root, ext = os.path.splitext(base_path)
    for i in range(1, 1000):
        candidate = f"{root}_{i:03d}{ext}"
        if not os.path.exists(candidate):
            return candidate
    raise RuntimeError("파일명 중복이 너무 많습니다 (999개 초과).")


def insert_qr_and_export(cfg: dict, qr_image_path: str) -> dict:
    """
    Excel COM으로 cover 파일을 열고, 지정 셀에 QR 이미지를 삽입한 뒤
    Excel 복사본과 PDF를 output_folder에 저장합니다.
    반환: {"excel_path": str, "pdf_path": str}
    """
    import win32com.client as win32

    cover_path = os.path.abspath(cfg["cover_excel_path"])
    sheet_name = cfg["sheet_name"]
    qr_cell    = cfg["qr_target_cell"]
    out_folder = os.path.abspath(cfg["output_folder"])
    qr_abs     = os.path.abspath(qr_image_path)

    report_id = cfg["report_id"]
    customer  = cfg["customer"]
    hull_no   = cfg["hull_no"]
    item_type = cfg["item_type"]
    item_code = cfg["item_code"]

    os.makedirs(out_folder, exist_ok=True)

    stem      = f"{report_id}_{customer}_{hull_no}_{item_type}_{item_code}_QR_Cover"
    excel_out = _get_unique_path(os.path.join(out_folder, stem + ".xls"))
    pdf_out   = _get_unique_path(os.path.join(out_folder, stem + ".pdf"))

    excel_app = None
    wb        = None
    try:
        excel_app = win32.Dispatch("Excel.Application")
        excel_app.Visible       = False
        excel_app.DisplayAlerts = False

        wb = excel_app.Workbooks.Open(cover_path)

        # 시트 선택
        try:
            ws = wb.Sheets(sheet_name)
        except Exception:
            available = [wb.Sheets(i + 1).Name for i in range(wb.Sheets.Count)]
            raise ValueError(
                f"시트 '{sheet_name}'를 찾을 수 없습니다. "
                f"사용 가능한 시트: {available}"
            )

        # 셀 좌표 취득 (포인트 단위)
        cell = ws.Range(qr_cell)
        left = cell.Left
        top  = cell.Top

        # QR 이미지 삽입 (80pt × 80pt)
        ws.Shapes.AddPicture(
            Filename=qr_abs,
            LinkToFile=False,
            SaveWithDocument=True,
            Left=left,
            Top=top,
            Width=80,
            Height=80,
        )

        # 지정 시트만 PDF 내보내기
        ws.ExportAsFixedFormat(
            Type=0,               # xlTypePDF
            Filename=pdf_out,
            Quality=0,            # xlQualityStandard
            IncludeDocProperties=True,
            IgnorePrintAreas=False,
            OpenAfterPublish=False,
        )

        # QR 포함된 Excel 복사본 저장 (원본은 수정하지 않음)
        wb.SaveCopyAs(excel_out)

    finally:
        if wb is not None:
            try:
                wb.Close(False)
            except Exception:
                pass
        if excel_app is not None:
            try:
                excel_app.Quit()
            except Exception:
                pass

    return {"excel_path": excel_out, "pdf_path": pdf_out}
