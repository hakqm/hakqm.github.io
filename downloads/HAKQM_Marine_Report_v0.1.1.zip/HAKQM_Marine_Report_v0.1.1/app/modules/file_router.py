import os
import shutil
from datetime import datetime


def get_series(hull_no: str) -> str:
    """Derive series folder name from hull number (V1 auto-calculation)."""
    try:
        base = (int(hull_no) // 10) * 10
        return f"{base}시리즈"
    except ValueError:
        return f"{hull_no}시리즈"


def _build_output_dir(output_root: str, customer: str, hull_no: str) -> str:
    return os.path.join(output_root, customer, get_series(hull_no), hull_no)


def _build_filename(report_id: str, customer: str, hull_no: str,
                    item_type: str, item_code: str) -> str:
    return f"{report_id}_{customer}_{hull_no}_{item_type}_{item_code}_스캔본.pdf"


def _unique_path(directory: str, filename: str) -> tuple[str, bool]:
    target = os.path.join(directory, filename)
    if not os.path.exists(target):
        return target, False
    base, ext = os.path.splitext(filename)
    for i in range(1, 1000):
        candidate = os.path.join(directory, f"{base}_{i:03d}{ext}")
        if not os.path.exists(candidate):
            return candidate, True
    raise FileExistsError(f"중복 경로 생성 실패: {filename}")


def _safe_move(src: str, dst_dir: str) -> str:
    os.makedirs(dst_dir, exist_ok=True)
    filename = os.path.basename(src)
    dst = os.path.join(dst_dir, filename)
    if os.path.exists(dst):
        base, ext = os.path.splitext(filename)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dst = os.path.join(dst_dir, f"{base}_{ts}{ext}")
    shutil.move(src, dst)
    return dst


def rename_series_folder(output_root: str, customer: str,
                         current_name: str, display_name: str) -> bool:
    """
    Rename output/customer/current_name → output/customer/display_name.
    Returns True if rename was performed, False if not needed.
    Raises RuntimeError on actual rename failure.
    """
    if current_name == display_name:
        return False
    old_path = os.path.join(output_root, customer, current_name)
    new_path = os.path.join(output_root, customer, display_name)
    if not os.path.exists(old_path):
        return False
    if os.path.exists(new_path):
        return False
    try:
        os.rename(old_path, new_path)
        return True
    except Exception as exc:
        raise RuntimeError(
            f"폴더가 열려 있거나 권한이 없어 폴더명을 변경하지 못했습니다. "
            f"[{old_path}] → [{new_path}]: {exc}"
        )


def save_pdf(src_path: str, output_root: str, customer: str, hull_no: str,
             item_type: str, item_code: str, report_id: str,
             series_folder_override: str = None) -> dict:
    """
    Copy PDF to the output directory tree and return result info.
    series_folder_override: V3 폴더표시명을 직접 지정. None이면 hull_no 기반 자동계산(V1).
    """
    if series_folder_override:
        dst_dir = os.path.join(output_root, customer, series_folder_override, hull_no)
        series = series_folder_override
    else:
        dst_dir = _build_output_dir(output_root, customer, hull_no)
        series = get_series(hull_no)

    os.makedirs(dst_dir, exist_ok=True)
    filename = _build_filename(report_id, customer, hull_no, item_type, item_code)
    target_path, is_duplicate = _unique_path(dst_dir, filename)
    shutil.copy2(src_path, target_path)

    return {
        "target_path": target_path,
        "series": series,
        "is_duplicate": is_duplicate,
    }


def move_to_processed(src_path: str, processed_dir: str) -> str:
    return _safe_move(src_path, processed_dir)


def move_to_error(src_path: str, error_dir: str) -> str:
    return _safe_move(src_path, error_dir)
