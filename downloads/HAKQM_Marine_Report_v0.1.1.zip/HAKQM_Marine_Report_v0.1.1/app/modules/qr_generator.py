import os

import qrcode
from PIL import Image


def build_qr_data(report_id: str, customer: str, hull_no: str, item_type: str, item_code: str) -> str:
    return f"HAKQM_TR|{report_id}|{customer}|{hull_no}|{item_type}|{item_code}"


def generate_qr_image(qr_data: str, output_path: str, size_px: int = 300) -> str:
    parent = os.path.dirname(output_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=2,
    )
    qr.add_data(qr_data)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    img = img.resize((size_px, size_px), Image.LANCZOS)
    img.save(output_path, "PNG")

    return output_path
