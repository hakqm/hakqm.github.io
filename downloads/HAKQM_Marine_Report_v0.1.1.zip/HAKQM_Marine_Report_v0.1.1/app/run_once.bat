@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo.
echo ====================================================
echo  HAKQM 성적서 자동분류 프로그램
echo ====================================================
echo.
python main.py --once
echo.
echo 처리가 완료되었습니다. 아무 키나 누르면 닫힙니다.
pause > nul
