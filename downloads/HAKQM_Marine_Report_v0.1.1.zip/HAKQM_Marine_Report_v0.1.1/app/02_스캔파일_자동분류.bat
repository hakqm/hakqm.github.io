@echo off
chcp 65001 >nul

cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" main.py --once
) else (
    python main.py --once
)

echo.
echo ================================
echo Auto sorting finished.
echo ================================
pause