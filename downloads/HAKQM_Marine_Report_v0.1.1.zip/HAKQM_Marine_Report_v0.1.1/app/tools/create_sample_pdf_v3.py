"""
V3 QR 테스트 PDF 생성 도구
실행: python tools/create_sample_pdf_v3.py

1. 04_master_excel/시리즈관리.xlsx에 테스트 시리즈 데이터를 등록합니다.
2. 01_scan_inbox에 V3 QR 코드가 포함된 테스트 PDF를 생성합니다.
"""

import json
import os
import sys

import openpyxl
import qrcode
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

QR_DATA = "HAKQM_TR_V3|HAK-TR-2026-000010|삼성중공업|SHI_2080_A|2087|AHU|A841-CC"
OUTPUT_FILENAME = "SCAN_TEST_V3_HAK-TR-2026-000010.pdf"

SERIES_SHEET = "시리즈관리"
SERIES_COLUMNS = ["고객사", "시리즈ID", "폴더표시명", "현재폴더명", "포함호선", "사용여부", "비고"]
TEST_SERIES_ROW = {
    "고객사": "삼성중공업",
    "시리즈ID": "SHI_2080_A",
    "폴더표시명": "2080~2083,2087,2089~2091",
    "현재폴더명": "2080~2083,2087,2089~2091",
    "포함호선": "2080,2081,2082,2083,2087,2089,2090,2091",
    "사용여부": "Y",
    "비고": "테스트",
}


def load_config() -> dict:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(script_dir, "..", "config.json")
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def setup_series_excel(series_excel_path: str):
    """시리즈관리.xlsx에 테스트 시리즈 행을 등록한다. 이미 있으면 건너뜀."""
    os.makedirs(os.path.dirname(series_excel_path), exist_ok=True)

    if os.path.exists(series_excel_path):
        wb = openpyxl.load_workbook(series_excel_path)
        ws = wb[SERIES_SHEET] if SERIES_SHEET in wb.sheetnames else wb.active
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = SERIES_SHEET
        for col, header in enumerate(SERIES_COLUMNS, 1):
            ws.cell(row=1, column=col, value=header)

    ci = {ws.cell(1, c).value: c for c in range(1, ws.max_column + 1) if ws.cell(1, c).value}

    # 중복 확인
    for row_idx in range(2, ws.max_row + 1):
        r_customer = str(ws.cell(row_idx, ci.get("고객사", 1)).value or "").strip()
        r_series_id = str(ws.cell(row_idx, ci.get("시리즈ID", 2)).value or "").strip()
        if r_customer == TEST_SERIES_ROW["고객사"] and r_series_id == TEST_SERIES_ROW["시리즈ID"]:
            print(f"[시리즈관리] 테스트 데이터 이미 존재: {TEST_SERIES_ROW['시리즈ID']}")
            return

    next_row = ws.max_row + 1
    for col, key in enumerate(SERIES_COLUMNS, 1):
        ws.cell(row=next_row, column=col, value=TEST_SERIES_ROW[key])
    wb.save(series_excel_path)
    print(f"[시리즈관리] 테스트 데이터 등록 완료: {series_excel_path}")
    print(f"  시리즈ID   : {TEST_SERIES_ROW['시리즈ID']}")
    print(f"  폴더표시명  : {TEST_SERIES_ROW['폴더표시명']}")


def generate_qr_image(save_path: str):
    qr = qrcode.QRCode(
        version=2,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=4,
    )
    qr.add_data(QR_DATA)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img.save(save_path)


def build_pdf(output_path: str, qr_img_path: str):
    c = canvas.Canvas(output_path, pagesize=A4)
    pw, ph = A4

    # ── Page 1: 더미 성적서 ───────────────────────────────────
    c.setFont("Helvetica-Bold", 18)
    c.drawCentredString(pw / 2, ph - 80, "INSPECTION TEST REPORT")

    c.setLineWidth(1)
    c.line(50, ph - 95, pw - 50, ph - 95)

    c.setFont("Helvetica-Bold", 11)
    c.drawString(60, ph - 130, "Document No.")
    c.setFont("Helvetica", 11)
    c.drawString(200, ph - 130, "HAK-TR-2026-000010")

    fields = [
        ("Customer",   "Samsung Heavy Industries"),
        ("Hull No.",   "2087"),
        ("Series ID",  "SHI_2080_A"),
        ("Item Type",  "AHU (Air Handling Unit)"),
        ("Item Code",  "A841-CC"),
        ("Inspection", "Factory Acceptance Test"),
        ("Date",       "2026-05-18"),
        ("Result",     "PASS"),
    ]
    y = ph - 160
    for label, value in fields:
        c.setFont("Helvetica-Bold", 10)
        c.drawString(60, y, label)
        c.setFont("Helvetica", 10)
        c.drawString(200, y, value)
        y -= 22

    c.setFont("Helvetica", 9)
    c.setFillColorRGB(0.5, 0.5, 0.5)
    c.drawCentredString(pw / 2, 50, "Page 1 / 2  |  HAKQM Auto Classification System - V3 Sample")
    c.showPage()

    # ── Page 2: QR 코드 ───────────────────────────────────────
    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(pw / 2, ph - 70, "HAKQM IDENTIFICATION PAGE  [V3]")

    c.setFont("Helvetica", 10)
    c.drawCentredString(pw / 2, ph - 95, "This page is scanned by the HAKQM auto-classification system.")

    c.setLineWidth(0.5)
    c.rect(40, 40, pw - 80, ph - 120)

    qr_size = 260
    qr_x = (pw - qr_size) / 2
    qr_y = (ph - qr_size) / 2 - 20
    c.drawImage(qr_img_path, qr_x, qr_y, width=qr_size, height=qr_size)

    c.setFont("Helvetica-Bold", 9)
    c.setFillColorRGB(0, 0, 0)
    c.drawCentredString(pw / 2, qr_y - 20, "QR DATA (V3):")
    c.setFont("Helvetica", 8)
    c.setFillColorRGB(0.2, 0.2, 0.2)
    c.drawCentredString(pw / 2, qr_y - 34, QR_DATA)

    c.setFont("Helvetica", 9)
    c.setFillColorRGB(0.5, 0.5, 0.5)
    c.drawCentredString(pw / 2, 50, "Page 2 / 2  |  HAKQM Auto Classification System - V3 Sample")
    c.save()


def main():
    config = load_config()
    scan_inbox = config["scan_inbox"]
    series_excel = config.get("series_excel", "")
    os.makedirs(scan_inbox, exist_ok=True)

    output_path = os.path.join(scan_inbox, OUTPUT_FILENAME)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    qr_temp = os.path.join(script_dir, "_qr_temp_v3.png")

    try:
        if series_excel:
            print("시리즈관리.xlsx 테스트 데이터 설정 중...")
            setup_series_excel(series_excel)
        else:
            print("[경고] config.json에 series_excel 경로가 없습니다.")

        print("QR 코드 생성 중...")
        generate_qr_image(qr_temp)

        print("PDF 생성 중...")
        build_pdf(output_path, qr_temp)

        print(f"\n[완료] V3 샘플 PDF 생성 성공")
        print(f"  저장 경로  : {output_path}")
        print(f"  QR 데이터  : {QR_DATA}")
        print()
        print("이제 다음 명령을 실행하세요:")
        print("  python main.py --once")
        print()
        print("테스트 성공 기준:")
        print(f"  05_output/삼성중공업/2080~2083,2087,2089~2091/2087/ 폴더 생성")
        print(f"  PDF 저장 및 검사현황.xlsx에 시리즈ID/시리즈폴더명 기록")

    except Exception as exc:
        print(f"[오류] {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        if os.path.exists(qr_temp):
            os.remove(qr_temp)


if __name__ == "__main__":
    main()
