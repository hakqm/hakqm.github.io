"""
샘플 테스트 PDF 생성 도구
실행: python tools/create_sample_pdf.py

2페이지 PDF를 생성합니다.
- 1페이지: 성적서 더미 내용
- 2페이지: HAKQM QR 코드
"""

import json
import os
import sys

import qrcode
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

QR_DATA = "HAKQM_TR|HAK-TR-2026-000001|삼성중공업|2626|AHU|A841-CC"
OUTPUT_FILENAME = "SCAN_TEST_HAK-TR-2026-000001.pdf"


def load_config() -> dict:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(script_dir, "..", "config.json")
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def generate_qr_image(save_path: str):
    qr = qrcode.QRCode(
        version=2,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=4,
    )
    qr.add_data(QR_DATA)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img.save(save_path)


def build_pdf(output_path: str, qr_img_path: str):
    c = canvas.Canvas(output_path, pagesize=A4)
    pw, ph = A4

    # ── Page 1: 더미 성적서 ───────────────────────────────────
    c.setFont("Helvetica-Bold", 18)
    c.drawCentredString(pw / 2, ph - 80, "INSPECTION TEST REPORT")

    c.setLineWidth(1)
    c.line(50, ph - 95, pw - 50, ph - 95)

    c.setFont("Helvetica-Bold", 11)
    c.drawString(60, ph - 130, "Document No.")
    c.setFont("Helvetica", 11)
    c.drawString(200, ph - 130, "HAK-TR-2026-000001")

    fields = [
        ("Customer",   "Samsung Heavy Industries"),
        ("Hull No.",   "2626"),
        ("Item Type",  "AHU (Air Handling Unit)"),
        ("Item Code",  "A841-CC"),
        ("Inspection", "Factory Acceptance Test"),
        ("Date",       "2026-05-18"),
        ("Result",     "PASS"),
    ]
    y = ph - 160
    for label, value in fields:
        c.setFont("Helvetica-Bold", 10)
        c.drawString(60, y, label)
        c.setFont("Helvetica", 10)
        c.drawString(200, y, value)
        y -= 22

    c.setFont("Helvetica", 9)
    c.setFillColorRGB(0.5, 0.5, 0.5)
    c.drawCentredString(pw / 2, 50, "Page 1 / 2  |  HAKQM Auto Classification System - Sample")
    c.showPage()

    # ── Page 2: QR 코드 ───────────────────────────────────────
    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(pw / 2, ph - 70, "HAKQM IDENTIFICATION PAGE")

    c.setFont("Helvetica", 10)
    c.drawCentredString(pw / 2, ph - 95, "This page is scanned by the HAKQM auto-classification system.")

    c.setLineWidth(0.5)
    c.rect(40, 40, pw - 80, ph - 120)

    qr_size = 260
    qr_x = (pw - qr_size) / 2
    qr_y = (ph - qr_size) / 2 - 20
    c.drawImage(qr_img_path, qr_x, qr_y, width=qr_size, height=qr_size)

    c.setFont("Helvetica-Bold", 9)
    c.drawCentredString(pw / 2, qr_y - 20, "QR DATA:")
    c.setFont("Helvetica", 8)
    c.setFillColorRGB(0.2, 0.2, 0.2)
    c.drawCentredString(pw / 2, qr_y - 34, QR_DATA)

    c.setFont("Helvetica", 9)
    c.setFillColorRGB(0.5, 0.5, 0.5)
    c.drawCentredString(pw / 2, 50, "Page 2 / 2  |  HAKQM Auto Classification System - Sample")

    c.save()


def main():
    config = load_config()
    scan_inbox = config["scan_inbox"]
    os.makedirs(scan_inbox, exist_ok=True)

    output_path = os.path.join(scan_inbox, OUTPUT_FILENAME)

    # Temp QR image path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    qr_temp = os.path.join(script_dir, "_qr_temp.png")

    try:
        print(f"QR 코드 생성 중...")
        generate_qr_image(qr_temp)

        print(f"PDF 생성 중...")
        build_pdf(output_path, qr_temp)

        print(f"\n[완료] 샘플 PDF 생성 성공")
        print(f"  경로  : {output_path}")
        print(f"  QR    : {QR_DATA}")
        print(f"\n이제 python main.py --once 를 실행하세요.")

    except Exception as exc:
        print(f"[오류] {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        if os.path.exists(qr_temp):
            os.remove(qr_temp)


if __name__ == "__main__":
    main()
