# HAKQM 성적서 자동분류 프로그램

PDF 성적서에서 HAKQM QR을 인식하여 자동으로 분류·저장하는 로컬 CLI 프로그램입니다.

---

## 폴더 구조

```
marine_ai/
├─ 01_scan_inbox/      # 처리할 PDF를 여기에 넣습니다
├─ 02_processed/       # 정상 처리된 원본 PDF
├─ 03_error/           # QR 인식 실패 PDF
├─ 04_master_excel/    # 검사현황.xlsx
├─ 05_output/          # 분류된 PDF 저장 위치
├─ 06_logs/            # 일별 로그 파일
└─ app/                # 프로그램 소스
    ├─ main.py
    ├─ config.json
    ├─ requirements.txt
    ├─ run_once.bat
    ├─ modules/
    │   ├─ qr_reader.py
    │   ├─ qr_parser.py
    │   ├─ file_router.py
    │   ├─ excel_writer.py
    │   └─ logger.py
    └─ tools/
        └─ create_sample_pdf.py
```

---

## 설치

```cmd
cd C:\Users\H-NN1455\Desktop\marine_ai\app
pip install -r requirements.txt
```

---

## 실행

### 단회 처리
```cmd
python main.py --once
```

### BAT 파일로 실행 (더블클릭)
```
run_once.bat
```

---

## 테스트용 샘플 PDF 생성

```cmd
python tools/create_sample_pdf.py
```

`01_scan_inbox/SCAN_TEST_HAK-TR-2026-000001.pdf` 가 생성됩니다.  
이후 `python main.py --once` 로 분류 처리를 확인할 수 있습니다.

---

## QR 데이터 형식

```
HAKQM_TR|HAK-TR-2026-000001|삼성중공업|2626|AHU|A841-CC
```

| 순서 | 필드 | 예시 |
|------|------|------|
| 1 | system | HAKQM_TR |
| 2 | report_id | HAK-TR-2026-000001 |
| 3 | customer | 삼성중공업 |
| 4 | hull_no | 2626 |
| 5 | item_type | AHU |
| 6 | item_code | A841-CC |

---

## 처리 흐름

1. `01_scan_inbox` 의 PDF를 순서대로 읽음
2. 2페이지에서 QR 우선 탐색 → 없으면 전체 페이지
3. `HAKQM_TR` 로 시작하는 QR만 인정
4. 파싱 성공 → `05_output/고객사/2620시리즈/2626/` 에 저장
5. 원본 PDF → `02_processed/` 이동
6. 인식 실패 → `03_error/` 이동
7. 모든 결과 → `04_master_excel/검사현황.xlsx` 기록

---

## 저장 파일명 규칙

```
HAK-TR-2026-000001_삼성중공업_2626_AHU_A841-CC_스캔본.pdf
```

동일 파일명 존재 시: `..._스캔본_001.pdf`, `..._스캔본_002.pdf` …

---

## 상태값

| 상태 | 의미 |
|------|------|
| 스캔등록완료 | 정상 처리 |
| 중복등록 | 동일 파일명 존재로 _00N 저장 |
| QR인식실패 | QR 없거나 읽기 오류 |
| 우리QR없음 | HAKQM_TR 아닌 타사 QR만 존재 |
| 저장실패 | 파일 저장 중 오류 |
