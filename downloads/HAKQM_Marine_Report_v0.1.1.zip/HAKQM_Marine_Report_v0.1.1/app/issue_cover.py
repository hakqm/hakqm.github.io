"""
HAKQM 성적서 Cover QR 삽입 및 PDF 저장
실행: python issue_cover.py
"""

import json
import os
import sys

BASE_DIR     = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE  = os.path.join(BASE_DIR, "issue_config.json")
TEMP_QR_DIR  = os.path.join(BASE_DIR, "temp_qr")

REQUIRED_KEYS = [
    "cover_excel_path", "sheet_name", "report_id", "customer",
    "hull_no", "item_type", "item_code", "qr_target_cell", "output_folder",
]


def _load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _safe_filename(name: str) -> str:
    for ch in r'\/:*?"<>|':
        name = name.replace(ch, "_")
    return name


def main():
    print("━━━ HAKQM 성적서 Cover QR 삽입 시작 ━━━")

    # ── 1. 설정 파일 로드 ──────────────────────────────────────
    if not os.path.isfile(CONFIG_FILE):
        print(f"[오류] issue_config.json을 찾을 수 없습니다: {CONFIG_FILE}")
        sys.exit(1)

    try:
        cfg = _load_config(CONFIG_FILE)
        print(f"[설정] 로드 완료: {CONFIG_FILE}")
    except Exception as e:
        print(f"[오류] issue_config.json 읽기 실패: {e}")
        sys.exit(1)

    missing = [k for k in REQUIRED_KEYS if k not in cfg]
    if missing:
        print(f"[오류] issue_config.json 필수 항목 누락: {', '.join(missing)}")
        sys.exit(1)

    cover_path = os.path.abspath(cfg["cover_excel_path"])
    if not os.path.isfile(cover_path):
        print(f"[오류] cover_excel_path 파일 없음: {cover_path}")
        sys.exit(1)

    # ── 2. QR 데이터 생성 ─────────────────────────────────────
    from modules.qr_generator import build_qr_data, generate_qr_image

    qr_data = build_qr_data(
        report_id=cfg["report_id"],
        customer=cfg["customer"],
        hull_no=cfg["hull_no"],
        item_type=cfg["item_type"],
        item_code=cfg["item_code"],
    )
    print(f"[QR데이터] {qr_data}")

    # ── 3. QR 이미지 파일 생성 ────────────────────────────────
    os.makedirs(TEMP_QR_DIR, exist_ok=True)
    qr_filename   = _safe_filename(
        f"{cfg['report_id']}_{cfg['hull_no']}_{cfg['item_code']}_qr.png"
    )
    qr_image_path = os.path.join(TEMP_QR_DIR, qr_filename)

    try:
        generate_qr_image(qr_data, qr_image_path, size_px=300)
        print(f"[QR생성] {qr_image_path}")
    except Exception as e:
        print(f"[오류] QR 이미지 생성 실패: {e}")
        sys.exit(1)

    # ── 4~11. Excel COM QR 삽입 → PDF/Excel 저장 ─────────────
    from modules.cover_qr_writer import insert_qr_and_export

    result = None
    try:
        result = insert_qr_and_export(cfg, qr_image_path)
    except Exception as e:
        print(f"[오류] Excel/PDF 생성 실패: {e}")
    finally:
        # 임시 QR 이미지 삭제
        try:
            if os.path.isfile(qr_image_path):
                os.remove(qr_image_path)
        except Exception:
            pass

    if result is None:
        sys.exit(1)

    # ── 12. 결과 출력 ─────────────────────────────────────────
    print(f"[Excel 저장] {result['excel_path']}")
    print(f"[PDF 저장]   {result['pdf_path']}")
    print("━━━ 처리 완료 ━━━")


if __name__ == "__main__":
    main()
