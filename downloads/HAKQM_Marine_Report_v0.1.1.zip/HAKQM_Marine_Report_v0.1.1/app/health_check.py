"""
HAKQM 환경점검 스크립트
실행: python health_check.py (app 폴더에서)
"""

import json
import os
import sys
from pathlib import Path

APP_DIR = Path(__file__).parent
BASE_DIR = APP_DIR.parent

issues = []
warnings = []


def ok(label, detail=""):
    suffix = f": {detail}" if detail else ""
    print(f"  [OK]   {label}{suffix}")


def fail(label, detail=""):
    suffix = f" → {detail}" if detail else ""
    print(f"  [!!]   {label}{suffix}")
    issues.append(label)


def warn(label, detail=""):
    suffix = f" → {detail}" if detail else ""
    print(f"  [주의] {label}{suffix}")
    warnings.append(label)


def info(label, detail=""):
    suffix = f" → {detail}" if detail else ""
    print(f"  [정보] {label}{suffix}")


# ── 헤더 ─────────────────────────────────────────────────────
print()
print("=" * 55)
print("  HAKQM 환경점검")
print("=" * 55)

# ── 1. Python 버전 ────────────────────────────────────────────
print(f"\n[1] Python 버전")
print(f"  {sys.version}")

# ── 2. config.json ────────────────────────────────────────────
print(f"\n[2] 설정 파일 (config.json)")
config_path = APP_DIR / "config.json"
config = {}
if config_path.exists():
    ok("config.json")
    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)
else:
    fail("config.json", f"없음: {config_path}")

# ── 3. 작업 폴더 ──────────────────────────────────────────────
print(f"\n[3] 작업 폴더 확인 및 생성")

REQUIRED_DIRS = [
    ("01_scan_inbox",  BASE_DIR / "01_scan_inbox"),
    ("02_processed",   BASE_DIR / "02_processed"),
    ("03_error",       BASE_DIR / "03_error"),
    ("04_master_excel",BASE_DIR / "04_master_excel"),
    ("05_output",      BASE_DIR / "05_output"),
    ("06_logs",        BASE_DIR / "06_logs"),
    ("07_manual",      BASE_DIR / "07_manual"),
    ("app/issued_cover", APP_DIR / "issued_cover"),
]

for name, path in REQUIRED_DIRS:
    if path.exists():
        ok(name)
    else:
        path.mkdir(parents=True, exist_ok=True)
        print(f"  [생성] {name} (새로 만들었습니다)")

# ── 4. 템플릿 파일 ────────────────────────────────────────────
print(f"\n[4] 템플릿 파일")
template_path = APP_DIR / "templates" / "Test_Report_Cover.xls"
if template_path.exists():
    ok("Test_Report_Cover.xls")
else:
    fail("Test_Report_Cover.xls", f"없음: {template_path}")

# ── 5. 마스터 엑셀 파일 ───────────────────────────────────────
print(f"\n[5] 마스터 엑셀 파일")
excel_dir = BASE_DIR / "04_master_excel"

insp_path = excel_dir / "검사현황.xlsx"
if insp_path.exists():
    ok("검사현황.xlsx")
else:
    info("검사현황.xlsx", "자동분류 실행 시 자동 생성됩니다")

series_path = excel_dir / "시리즈관리.xlsx"
if series_path.exists():
    ok("시리즈관리.xlsx")
else:
    warn("시리즈관리.xlsx", "V3 QR 처리 시 오류 발생 가능")

items_path = excel_dir / "품목관리.xlsx"
if items_path.exists():
    ok("품목관리.xlsx")
else:
    info("품목관리.xlsx", "Cover 발행 GUI 실행 시 자동 생성 가능")

# ── 6. 열린 파일 경고 ─────────────────────────────────────────
print(f"\n[6] 열린 파일 주의사항")
print(f"  자동분류 실행 전 아래 파일을 Excel에서 닫아 주세요:")
print(f"    - 검사현황.xlsx")
print(f"    - 시리즈관리.xlsx")
print(f"    - 품목관리.xlsx")
print(f"  파일이 열려 있으면 자동 저장이 실패합니다.")

# ── 7. 라이브러리 확인 ────────────────────────────────────────
print(f"\n[7] 필수 라이브러리")

LIB_CHECKS = [
    ("fitz (PyMuPDF)",   "fitz"),
    ("cv2 (OpenCV)",     "cv2"),
    ("numpy",            "numpy"),
    ("openpyxl",         "openpyxl"),
    ("qrcode",           "qrcode"),
    ("PIL (Pillow)",     "PIL"),
    ("win32com",         "win32com.client"),
]

for label, module_name in LIB_CHECKS:
    try:
        __import__(module_name)
        ok(label)
    except ImportError:
        pip_name = module_name.split(".")[0]
        fail(label, f"pip install {pip_name} 필요")

# ── 8. Excel COM 확인 ─────────────────────────────────────────
print(f"\n[8] Excel COM 연결 확인")
try:
    import win32com.client
    xl = win32com.client.Dispatch("Excel.Application")
    xl.Quit()
    ok("Excel COM 연결")
except Exception as e:
    fail("Excel COM 연결", "Excel이 설치되어 있지 않거나 권한 문제일 수 있습니다")
    print(f"         오류 내용: {e}")

# ── 최종 결과 ─────────────────────────────────────────────────
print()
print("=" * 55)
if issues:
    print(f"  조치 필요 항목 ({len(issues)}개):")
    for item in issues:
        print(f"    - {item}")
    print()
    print("  >> 환경점검: 조치 필요 <<")
else:
    if warnings:
        print(f"  주의 항목 ({len(warnings)}개):")
        for w in warnings:
            print(f"    - {w}")
        print()
    print("  >> 환경점검 완료 <<")
print("=" * 55)
print()
