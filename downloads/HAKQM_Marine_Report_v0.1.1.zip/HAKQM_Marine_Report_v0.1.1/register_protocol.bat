@echo off
chcp 65001 >nul

set "BASE=%~dp0"

echo Registering HAKQM custom protocols (hidden VBS mode)...
echo Base path: %BASE%
echo.

reg add "HKCU\Software\Classes\hakqm-cover" /ve /d "URL:HAKQM Cover" /f
reg add "HKCU\Software\Classes\hakqm-cover" /v "URL Protocol" /d "" /f
reg add "HKCU\Software\Classes\hakqm-cover\shell" /f
reg add "HKCU\Software\Classes\hakqm-cover\shell\open" /f
reg add "HKCU\Software\Classes\hakqm-cover\shell\open\command" /ve /d "\"%SystemRoot%\System32\wscript.exe\" \"%BASE%run_cover_hidden.vbs\"" /f

reg add "HKCU\Software\Classes\hakqm-sort" /ve /d "URL:HAKQM Sort" /f
reg add "HKCU\Software\Classes\hakqm-sort" /v "URL Protocol" /d "" /f
reg add "HKCU\Software\Classes\hakqm-sort\shell" /f
reg add "HKCU\Software\Classes\hakqm-sort\shell\open" /f
reg add "HKCU\Software\Classes\hakqm-sort\shell\open\command" /ve /d "\"%SystemRoot%\System32\wscript.exe\" \"%BASE%run_sort_hidden.vbs\"" /f

reg add "HKCU\Software\Classes\hakqm-check" /ve /d "URL:HAKQM Check" /f
reg add "HKCU\Software\Classes\hakqm-check" /v "URL Protocol" /d "" /f
reg add "HKCU\Software\Classes\hakqm-check\shell" /f
reg add "HKCU\Software\Classes\hakqm-check\shell\open" /f
reg add "HKCU\Software\Classes\hakqm-check\shell\open\command" /ve /d "\"%SystemRoot%\System32\wscript.exe\" \"%BASE%run_check_hidden.vbs\"" /f

echo.
echo ==========================================
echo HAKQM custom protocols registered (hidden mode).
echo.
echo Test commands:
echo start "" "hakqm-cover://run"
echo start "" "hakqm-sort://run"
echo start "" "hakqm-check://run"
echo ==========================================
pause
