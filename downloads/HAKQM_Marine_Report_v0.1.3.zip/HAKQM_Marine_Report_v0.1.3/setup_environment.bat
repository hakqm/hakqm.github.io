@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ============================================================
echo  HAKQM Marine Report - Environment Setup
echo ============================================================
echo.

:: Step 1: Set base directory
set "BASE_DIR=%~dp0"
if "%BASE_DIR:~-1%"=="\" set "BASE_DIR=%BASE_DIR:~0,-1%"
echo [Step 1] Base directory: "%BASE_DIR%"

:: Step 2: Check app folder
echo [Step 2] Checking app folder...
if not exist "%BASE_DIR%\app" (
    echo [ERROR] app folder not found: "%BASE_DIR%\app"
    echo         Make sure you extracted the package correctly.
    pause
    exit /b 1
)
echo         OK - app folder found.
echo.

:: Step 3: Find Python
echo [Step 3] Locating Python...
set "PYTHON_CMD="

py -3 --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=py -3"
    echo         OK - Found: py -3
    goto :found_python
)

python --version >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=python"
    echo         OK - Found: python
    goto :found_python
)

echo [ERROR] Python not found.
echo         Please install Python 3.x from: https://www.python.org/downloads/
echo         Make sure to check "Add Python to PATH" during installation.
pause
exit /b 1

:found_python
echo.

:: Step 4: Create virtual environment if not exists
echo [Step 4] Checking virtual environment...
if not exist "%BASE_DIR%\app\.venv" (
    echo         Creating virtual environment at: "%BASE_DIR%\app\.venv"
    %PYTHON_CMD% -m venv "%BASE_DIR%\app\.venv"
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        echo         Check that Python is correctly installed.
        pause
        exit /b 1
    )
    echo         OK - Virtual environment created.
) else (
    echo         OK - Virtual environment already exists.
)
echo.

:: Step 5: Upgrade pip
echo [Step 5] Upgrading pip...
"%BASE_DIR%\app\.venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
if errorlevel 1 (
    echo [WARNING] pip upgrade failed. Continuing with current version...
) else (
    echo         OK - pip upgraded.
)
echo.

:: Step 6: Install packages from requirements.txt
echo [Step 6] Installing packages from requirements.txt...
if not exist "%BASE_DIR%\app\requirements.txt" (
    echo [ERROR] requirements.txt not found: "%BASE_DIR%\app\requirements.txt"
    pause
    exit /b 1
)
echo         Please wait, this may take a few minutes...
"%BASE_DIR%\app\.venv\Scripts\python.exe" -m pip install -r "%BASE_DIR%\app\requirements.txt"
if errorlevel 1 (
    echo [ERROR] Package installation failed.
    echo         Check your internet connection and try again.
    pause
    exit /b 1
)
echo         OK - Packages installed.
echo.

:: Step 7: Verify python.exe exists
echo [Step 7] Verifying python.exe...
if not exist "%BASE_DIR%\app\.venv\Scripts\python.exe" (
    echo [ERROR] python.exe not found after setup.
    echo         Path: "%BASE_DIR%\app\.venv\Scripts\python.exe"
    pause
    exit /b 1
)
echo         OK - python.exe verified.
echo.

:: Step 8: Register custom protocols (auto-confirm pause)
echo [Step 8] Registering custom protocols...
if exist "%BASE_DIR%\register_protocol.bat" (
    echo. | call "%BASE_DIR%\register_protocol.bat"
) else (
    echo [WARNING] register_protocol.bat not found. Skipping protocol registration.
)
echo.

:: Done
echo ============================================================
echo  Setup complete!
echo ============================================================
echo.
echo  Next steps:
echo    1. Run the health check to verify the environment.
echo    2. Open the HAKQM portal and run Cover Issue or Scan Sort.
echo    3. If you move this folder later, run register_protocol.bat again.
echo.
pause
endlocal
