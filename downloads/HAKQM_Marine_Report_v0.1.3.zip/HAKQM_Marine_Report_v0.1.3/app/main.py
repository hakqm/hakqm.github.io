"""
HAKQM 성적서 자동분류 프로그램
실행: python main.py --once
"""

import argparse
import json
import os
import sys
from datetime import datetime

from modules.excel_writer import append_record
from modules.file_router import get_series, move_to_error, move_to_processed, rename_series_folder, save_pdf
from modules.logger import setup_logger
from modules.qr_parser import parse_qr_data
from modules.qr_reader import read_qr_from_pdf
from modules.series_manager import get_series_info, update_current_folder


def load_config(config_path: str) -> dict:
    from modules import path_manager
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    master_dir = path_manager.get_master_excel_dir()
    cfg["scan_inbox"]   = path_manager.get_scan_inbox_dir()
    cfg["processed"]    = path_manager.get_processed_dir()
    cfg["error"]        = path_manager.get_error_dir()
    cfg["output"]       = path_manager.get_output_dir()
    cfg["excel_path"]   = os.path.join(master_dir, "검사현황.xlsx")
    cfg["series_excel"] = os.path.join(master_dir, "시리즈관리.xlsx")
    cfg["logs"]         = path_manager.get_logs_dir()
    return cfg


def process_file(pdf_path: str, config: dict, logger) -> str:
    """
    Process a single PDF file.
    Returns the final status string.
    """
    filename = os.path.basename(pdf_path)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    base_record = {"처리일시": now, "원본파일명": filename}

    logger.info(f"[시작] {filename}")

    # ── QR 인식 ──────────────────────────────────────────────
    qr_result = read_qr_from_pdf(pdf_path, config["qr_prefix"])

    if qr_result["status"] == "error":
        logger.error(f"[오류] {filename} → QR 읽기 실패: {qr_result.get('error', '')}")
        move_to_error(pdf_path, config["error"])
        append_record(config["excel_path"], {
            **base_record, "상태": "QR인식실패",
            "비고": f"읽기 오류: {qr_result.get('error', '')}",
        })
        return "QR인식실패"

    if qr_result["status"] == "no_qr":
        msg = "HAKQM QR을 찾지 못했습니다. 고객사 QR만 있거나 QR이 없는 문서일 수 있습니다."
        logger.warning(f"[실패] {filename} → {msg}")
        move_to_error(pdf_path, config["error"])
        append_record(config["excel_path"], {
            **base_record, "상태": "QR인식실패", "비고": "QR 코드 없음",
        })
        return "QR인식실패"

    if qr_result["status"] == "other_qr":
        msg = "HAKQM QR을 찾지 못했습니다. 고객사 QR만 있거나 QR이 없는 문서일 수 있습니다."
        logger.warning(f"[스킵] {filename} → {msg}")
        move_to_error(pdf_path, config["error"])
        append_record(config["excel_path"], {
            **base_record, "상태": "우리QR없음", "비고": "HAKQM_TR 아닌 QR 존재",
        })
        return "우리QR없음"

    # ── QR 파싱 ──────────────────────────────────────────────
    parsed = parse_qr_data(qr_result["data"])
    if not parsed:
        logger.error(f"[오류] {filename} → QR 파싱 실패: {qr_result['data']}")
        move_to_error(pdf_path, config["error"])
        append_record(config["excel_path"], {
            **base_record, "상태": "QR인식실패",
            "비고": f"파싱 실패: {qr_result['data']}",
        })
        return "QR인식실패"

    qr_version = parsed.get("qr_version", "V1")
    logger.info(
        f"[인식] {filename} → [{qr_version}] {parsed['report_id']} / "
        f"{parsed['customer']} / 호선 {parsed['hull_no']} (p.{qr_result['page']})"
    )

    # ── V3: 시리즈 조회 및 폴더명 처리 ──────────────────────────
    series_folder_override = None
    series_id = parsed.get("series_id") or ""
    series_folder = ""
    note = ""

    if qr_version == "V3":
        series_excel = config.get("series_excel", "")
        series_info = get_series_info(series_excel, parsed["customer"], series_id)

        if not series_info:
            reason = f"시리즈관리.xlsx에 해당 시리즈ID가 없습니다. ({parsed['customer']} / {series_id})"
            logger.error(f"[오류] {filename} → {reason}")
            move_to_error(pdf_path, config["error"])
            append_record(config["excel_path"], {
                **base_record,
                "report_id": parsed["report_id"],
                "customer": parsed["customer"],
                "series_id": series_id,
                "hull_no": parsed["hull_no"],
                "item_type": parsed["item_type"],
                "item_code": parsed["item_code"],
                "상태": "저장실패",
                "비고": reason,
            })
            return "저장실패"

        display_name = series_info["display_name"]
        current_name = series_info["current_folder_name"]

        # 폴더명 변경이 필요한 경우 처리
        try:
            renamed = rename_series_folder(
                config["output"], parsed["customer"], current_name, display_name
            )
            if renamed:
                update_current_folder(series_excel, parsed["customer"], series_id, display_name)
                logger.info(f"[폴더변경] '{current_name}' → '{display_name}'")
        except RuntimeError as exc:
            logger.error(f"[오류] {filename} → {exc}")
            move_to_error(pdf_path, config["error"])
            append_record(config["excel_path"], {
                **base_record,
                "report_id": parsed["report_id"],
                "customer": parsed["customer"],
                "series_id": series_id,
                "series_folder": display_name,
                "hull_no": parsed["hull_no"],
                "item_type": parsed["item_type"],
                "item_code": parsed["item_code"],
                "상태": "저장실패",
                "비고": str(exc),
            })
            return "저장실패"

        series_folder_override = display_name
        series_folder = display_name

    else:
        # V1: 기존 방식 유지
        note = "V1 QR, 자동계산 사용"

    # ── PDF 저장 ──────────────────────────────────────────────
    try:
        save_result = save_pdf(
            src_path=pdf_path,
            output_root=config["output"],
            customer=parsed["customer"],
            hull_no=parsed["hull_no"],
            item_type=parsed["item_type"],
            item_code=parsed["item_code"],
            report_id=parsed["report_id"],
            series_folder_override=series_folder_override,
        )
    except Exception as exc:
        logger.error(f"[오류] {filename} → 저장 실패: {exc}")
        move_to_error(pdf_path, config["error"])
        append_record(config["excel_path"], {
            **base_record,
            "report_id": parsed["report_id"],
            "customer": parsed["customer"],
            "series_id": series_id,
            "series_folder": series_folder,
            "hull_no": parsed["hull_no"],
            "series": series_folder or get_series(parsed["hull_no"]),
            "item_type": parsed["item_type"],
            "item_code": parsed["item_code"],
            "상태": "저장실패",
            "비고": str(exc),
        })
        return "저장실패"

    # ── 원본 이동 ─────────────────────────────────────────────
    move_to_processed(pdf_path, config["processed"])

    status = "중복등록" if save_result["is_duplicate"] else "스캔등록완료"
    logger.info(f"[완료] {filename} → {status} : {save_result['target_path']}")

    append_record(config["excel_path"], {
        **base_record,
        "report_id": parsed["report_id"],
        "customer": parsed["customer"],
        "series_id": series_id,
        "series_folder": series_folder,
        "hull_no": parsed["hull_no"],
        "series": save_result["series"],
        "item_type": parsed["item_type"],
        "item_code": parsed["item_code"],
        "상태": status,
        "저장경로": save_result["target_path"],
        "비고": note,
    })

    return status


def run_once(config: dict, logger):
    scan_inbox = config["scan_inbox"]
    if not os.path.isdir(scan_inbox):
        logger.error(f"scan_inbox 경로가 없습니다: {scan_inbox}")
        return

    pdf_files = sorted(
        f for f in os.listdir(scan_inbox) if f.lower().endswith(".pdf")
    )

    if not pdf_files:
        msg = "처리할 PDF가 없습니다. 01_scan_inbox 폴더를 확인하세요."
        logger.info(msg)
        print(f"\n{msg}\n")
        return

    logger.info(f"처리 대상: {len(pdf_files)}개 파일")

    counters = {
        "스캔등록완료": 0, "QR인식실패": 0, "우리QR없음": 0,
        "저장실패": 0, "중복등록": 0,
    }

    for filename in pdf_files:
        pdf_path = os.path.join(scan_inbox, filename)
        status = process_file(pdf_path, config, logger)
        if status in counters:
            counters[status] += 1

    logger.info("=" * 55)
    logger.info("처리 완료 요약")
    for k, v in counters.items():
        if v:
            logger.info(f"  {k}: {v}건")
    logger.info("=" * 55)

    # CMD 요약 출력 (타임스탬프 없이 읽기 쉽게)
    success = counters["스캔등록완료"] + counters["중복등록"]
    failure = counters["QR인식실패"] + counters["우리QR없음"] + counters["저장실패"]
    print()
    print("─" * 40)
    print(f"  처리 대상: {len(pdf_files)}건")
    print(f"  성공:      {success}건")
    print(f"  실패:      {failure}건")
    if failure:
        print(f"  오류 폴더: {config['error']}")
    print("─" * 40)


def main():
    parser = argparse.ArgumentParser(description="HAKQM 성적서 자동분류 프로그램")
    parser.add_argument("--once", action="store_true", help="스캔 폴더 단회 처리")
    parser.add_argument("--config", default="config.json", help="설정 파일 경로")
    args = parser.parse_args()

    if not args.once:
        print("사용법: python main.py --once")
        sys.exit(1)

    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), args.config)
    if not os.path.isfile(config_path):
        print(f"config.json을 찾을 수 없습니다: {config_path}")
        sys.exit(1)

    config = load_config(config_path)
    logger = setup_logger(config["logs"])

    logger.info("━━━ HAKQM 성적서 자동분류 시작 ━━━")
    run_once(config, logger)
    logger.info("━━━ HAKQM 성적서 자동분류 종료 ━━━")


if __name__ == "__main__":
    main()
