"""
마스터 데이터 관리 모듈
- 품목관리.xlsx 생성/조회
- 시리즈관리.xlsx 조회
- Report ID 자동 생성
"""

import os
import re
from datetime import date

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

# 경로 상수
_MODULE_DIR   = os.path.dirname(os.path.abspath(__file__))
APP_DIR       = os.path.dirname(_MODULE_DIR)

try:
    from .path_manager import get_master_excel_dir, get_issued_cover_dir
except ImportError:
    from modules.path_manager import get_master_excel_dir, get_issued_cover_dir

MASTER_DIR    = get_master_excel_dir()
SERIES_EXCEL  = os.path.join(MASTER_DIR, "시리즈관리.xlsx")
ITEM_EXCEL    = os.path.join(MASTER_DIR, "품목관리.xlsx")
ISSUED_COVER  = get_issued_cover_dir()
INSPECT_EXCEL = os.path.join(MASTER_DIR, "검사현황.xlsx")

# 품목관리.xlsx 컬럼 및 너비
ITEM_COLUMNS    = ["커버종류", "ITEM", "ITEM CODE", "기본수량", "사용여부", "비고"]
ITEM_COL_WIDTHS = [15, 30, 15, 10, 10, 20]

# 품목관리.xlsx 초기 예시 데이터
ITEM_SAMPLE_DATA = [
    {"커버종류": "C(AHU)", "ITEM": "AIR HANDLING UNIT",         "ITEM CODE": "A841-CC", "기본수량": 2, "사용여부": "Y", "비고": "테스트"},
    {"커버종류": "C(PCD)", "ITEM": "PACKAGE COOLING DRAIN PAN", "ITEM CODE": "M588-UU", "기본수량": 1, "사용여부": "Y", "비고": "테스트"},
    {"커버종류": "C(PFD)", "ITEM": "PRE FILTER",                 "ITEM CODE": "PFD-001", "기본수량": 1, "사용여부": "Y", "비고": "테스트"},
]

# Report ID 패턴 (HAK-TR-2026-000001)
_REPORT_ID_RE = re.compile(r"HAK-TR-(\d{4})-(\d{6})")


# ── 품목관리.xlsx ────────────────────────────────────────────────────────────

def ensure_item_excel():
    """품목관리.xlsx가 없으면 예시 데이터를 포함해 생성"""
    if os.path.exists(ITEM_EXCEL):
        return

    os.makedirs(MASTER_DIR, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "품목관리"

    font  = Font(bold=True, color="FFFFFF")
    fill  = PatternFill(fill_type="solid", fgColor="2F5496")
    align = Alignment(horizontal="center", vertical="center")

    for col, (header, width) in enumerate(zip(ITEM_COLUMNS, ITEM_COL_WIDTHS), 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font      = font
        cell.fill      = fill
        cell.alignment = align
        ws.column_dimensions[cell.column_letter].width = width

    for row_idx, row_data in enumerate(ITEM_SAMPLE_DATA, 2):
        for col, header in enumerate(ITEM_COLUMNS, 1):
            ws.cell(row=row_idx, column=col, value=row_data.get(header, ""))

    ws.freeze_panes = "A2"
    wb.save(ITEM_EXCEL)


def _load_item_rows() -> list:
    """품목관리.xlsx에서 사용여부 Y인 행 데이터 로드"""
    ensure_item_excel()
    wb = openpyxl.load_workbook(ITEM_EXCEL, data_only=True)
    ws = wb.active

    col_map = {
        ws.cell(1, c).value: c
        for c in range(1, ws.max_column + 1)
        if ws.cell(1, c).value
    }

    rows = []
    for r in range(2, ws.max_row + 1):
        use_col = col_map.get("사용여부", 5)
        use = str(ws.cell(r, use_col).value or "").strip()
        if use.upper() != "Y":
            continue
        rows.append({col: ws.cell(r, c).value for col, c in col_map.items()})
    return rows


def get_cover_types() -> list:
    """사용 가능한 커버종류 목록 반환 (중복 제거, 순서 유지)"""
    seen = []
    for row in _load_item_rows():
        ct = str(row.get("커버종류") or "").strip()
        if ct and ct not in seen:
            seen.append(ct)
    return seen


def get_item_by_cover_type(cover_type: str) -> dict:
    """커버종류로 ITEM, ITEM CODE, 기본수량 반환. 없으면 빈 dict"""
    for row in _load_item_rows():
        if str(row.get("커버종류") or "").strip() == cover_type:
            return {
                "item":      str(row.get("ITEM") or ""),
                "item_code": str(row.get("ITEM CODE") or ""),
                "qty":       str(row.get("기본수량") or ""),
            }
    return {}


# ── 시리즈관리.xlsx ──────────────────────────────────────────────────────────

def _load_series_rows() -> list:
    """시리즈관리.xlsx에서 사용여부 Y인 행 데이터 로드"""
    if not os.path.exists(SERIES_EXCEL):
        return []

    wb = openpyxl.load_workbook(SERIES_EXCEL, data_only=True)
    ws = wb.active

    col_map = {
        ws.cell(1, c).value: c
        for c in range(1, ws.max_column + 1)
        if ws.cell(1, c).value
    }

    rows = []
    for r in range(2, ws.max_row + 1):
        use_col = col_map.get("사용여부", 6)
        use = str(ws.cell(r, use_col).value or "").strip()
        if use.upper() != "Y":
            continue
        rows.append({col: ws.cell(r, c).value for col, c in col_map.items()})
    return rows


def get_customers() -> list:
    """사용 가능한 고객사 목록 반환 (중복 제거, 순서 유지)"""
    seen = []
    for row in _load_series_rows():
        c = str(row.get("고객사") or "").strip()
        if c and c not in seen:
            seen.append(c)
    return seen


def get_series_by_customer(customer: str) -> list:
    """
    고객사별 시리즈 목록 반환
    반환: [{"display": 폴더표시명, "series_id": 시리즈ID, "hull_nos": 포함호선}, ...]
    """
    result = []
    for row in _load_series_rows():
        if str(row.get("고객사") or "").strip() == customer:
            result.append({
                "display":   str(row.get("폴더표시명") or ""),
                "series_id": str(row.get("시리즈ID") or ""),
                "hull_nos":  str(row.get("포함호선") or ""),
            })
    return result


def update_series_hull(customer: str, series_id: str, hull_no: str):
    """시리즈관리.xlsx에서 해당 행의 포함호선에 hull_no 추가 (중복 시 생략)"""
    if not os.path.exists(SERIES_EXCEL):
        return

    wb = openpyxl.load_workbook(SERIES_EXCEL)
    ws = wb.active

    col_map = {
        ws.cell(1, c).value: c
        for c in range(1, ws.max_column + 1)
        if ws.cell(1, c).value
    }

    hull_str = str(hull_no).strip()
    for r in range(2, ws.max_row + 1):
        r_cust = str(ws.cell(r, col_map["고객사"]).value or "").strip()
        r_sid  = str(ws.cell(r, col_map["시리즈ID"]).value or "").strip()
        if r_cust == customer and r_sid == series_id:
            existing  = str(ws.cell(r, col_map["포함호선"]).value or "").strip()
            hull_list = [h.strip() for h in existing.split(",") if h.strip()]
            if hull_str not in hull_list:
                hull_list.append(hull_str)
                ws.cell(r, col_map["포함호선"]).value = ", ".join(hull_list)
            break

    wb.save(SERIES_EXCEL)


# ── Report ID 자동 생성 ──────────────────────────────────────────────────────

def get_next_report_id() -> str:
    """
    issued_cover 폴더 + 검사현황.xlsx를 스캔해 올해 최대 번호 + 1로 Report ID 생성
    형식: HAK-TR-YYYY-000001
    """
    year_str = str(date.today().year)
    max_num  = 0

    # issued_cover 폴더의 파일명에서 번호 스캔
    if os.path.isdir(ISSUED_COVER):
        for fname in os.listdir(ISSUED_COVER):
            m = _REPORT_ID_RE.search(fname)
            if m and m.group(1) == year_str:
                max_num = max(max_num, int(m.group(2)))

    # 검사현황.xlsx의 모든 셀에서 번호 스캔
    if os.path.isfile(INSPECT_EXCEL):
        try:
            wb = openpyxl.load_workbook(INSPECT_EXCEL, read_only=True, data_only=True)
            for ws in wb.worksheets:
                for row in ws.iter_rows(values_only=True):
                    for cell_val in row:
                        if cell_val is None:
                            continue
                        m = _REPORT_ID_RE.search(str(cell_val))
                        if m and m.group(1) == year_str:
                            max_num = max(max_num, int(m.group(2)))
            wb.close()
        except Exception:
            pass

    return f"HAK-TR-{year_str}-{max_num + 1:06d}"
