"""
HAKQM 경로 관리 모듈

mode:
  local  (현재) - marine_ai 루트 기준 상대경로
  shared (추후) - 공유폴더 기반 경로로 전환 가능
"""

import os

_MODE = "local"
_SHARED_ROOT = None  # 추후 shared 모드: 공유 드라이브 루트 경로 지정


def _local_root() -> str:
    # path_manager.py 위치: app/modules/ → 상위 3단계 = marine_ai 루트
    return os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )


def _data_root() -> str:
    """데이터 폴더 기준 루트 (local=marine_ai루트, shared=공유드라이브루트)"""
    if _MODE == "shared" and _SHARED_ROOT:
        return _SHARED_ROOT
    return _local_root()


def get_root_dir() -> str:
    """marine_ai 루트 디렉토리 (항상 로컬 기준)"""
    return _local_root()


def get_app_dir() -> str:
    """app 디렉토리 (항상 로컬 기준)"""
    return os.path.join(_local_root(), "app")


def get_scan_inbox_dir() -> str:
    return os.path.join(_data_root(), "01_scan_inbox")


def get_processed_dir() -> str:
    return os.path.join(_data_root(), "02_processed")


def get_error_dir() -> str:
    return os.path.join(_data_root(), "03_error")


def get_master_excel_dir() -> str:
    return os.path.join(_data_root(), "04_master_excel")


def get_output_dir() -> str:
    return os.path.join(_data_root(), "05_output")


def get_logs_dir() -> str:
    return os.path.join(_data_root(), "06_logs")


def get_template_dir() -> str:
    """템플릿은 항상 로컬 app/templates"""
    return os.path.join(_local_root(), "app", "templates")


def get_issued_cover_dir() -> str:
    return os.path.join(_local_root(), "app", "issued_cover")
