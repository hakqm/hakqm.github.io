"""
HAKQM 성적서 QR Cover GUI 생성 프로그램
실행: python gui_issue_cover.py
"""

import os
import re
import shutil
import tkinter as tk
from tkinter import messagebox, ttk
from datetime import date

# 경로 상수
from modules import path_manager as _pm
BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_PATH = os.path.join(_pm.get_template_dir(), "Test_Report_Cover.xls")
OUTPUT_FOLDER = _pm.get_issued_cover_dir()
TEMP_QR_DIR   = os.path.join(BASE_DIR, "temp_qr")
SCAN_INBOX    = _pm.get_scan_inbox_dir()

# 커버종류별 셀 매핑 (추후 시트 추가 시 여기에 항목 추가)
CELL_MAP = {
    "C(AHU)": {
        "date":      "W11",
        "customer":  "O16",
        "hull_no":   "O18",
        "item":      "J24",
        "item_code": "J25",
        "qty":       "X24",
    }
}

_ITEM_TYPE_RE = re.compile(r"\((\w+)\)")


def _extract_item_type(sheet_name: str) -> str:
    """시트명에서 ITEM TYPE 추출 (예: C(AHU) → AHU)"""
    m = _ITEM_TYPE_RE.search(sheet_name)
    return m.group(1) if m else sheet_name


def _safe_filename(name: str) -> str:
    for ch in r'\/:*?"<>|':
        name = name.replace(ch, "_")
    return name


def _unique_path(base_path: str) -> str:
    if not os.path.exists(base_path):
        return base_path
    root, ext = os.path.splitext(base_path)
    for i in range(1, 1000):
        candidate = f"{root}_{i:03d}{ext}"
        if not os.path.exists(candidate):
            return candidate
    raise RuntimeError("파일명 중복이 999개를 초과했습니다.")


# ── QR 생성 ──────────────────────────────────────────────────────────────────

def _build_qr_data_v3(report_id, customer, series_id, hull_no, item_type, item_code) -> str:
    """V3 QR 데이터 문자열 생성"""
    return f"HAKQM_TR_V3|{report_id}|{customer}|{series_id}|{hull_no}|{item_type}|{item_code}"


def _generate_qr_image(qr_data: str, output_path: str, size_px: int = 300) -> str:
    """QR 코드 PNG 이미지 생성"""
    import qrcode
    from PIL import Image

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=2,
    )
    qr.add_data(qr_data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    img = img.resize((size_px, size_px), Image.LANCZOS)
    img.save(output_path, "PNG")
    return output_path


# ── Excel COM Cover 생성 ──────────────────────────────────────────────────────

def _create_cover(cfg: dict) -> dict:
    """
    Excel COM으로 템플릿을 열고 셀 값 입력 → QR 삽입 → PDF·Excel 저장
    반환: {"excel_path": str, "pdf_path": str}
    """
    import win32com.client as win32

    sheet_name = cfg["sheet_name"]

    # 지원하지 않는 커버종류 차단
    if sheet_name not in CELL_MAP:
        raise ValueError(f"아직 지원하지 않는 커버 종류입니다: {sheet_name}")

    cell_map   = CELL_MAP[sheet_name]
    cover_path = os.path.abspath(TEMPLATE_PATH)
    qr_cell    = cfg["qr_target_cell"]
    qr_abs     = os.path.abspath(cfg["qr_image_path"])
    out_folder = os.path.abspath(OUTPUT_FOLDER)

    report_id = cfg["report_id"]
    customer  = cfg["customer"]
    hull_no   = cfg["hull_no"]
    item_type = cfg["item_type"]
    item_code = cfg["item_code"]

    os.makedirs(out_folder, exist_ok=True)

    stem      = f"{report_id}_{customer}_{hull_no}_{item_type}_{item_code}_QR_Cover"
    excel_out = _unique_path(os.path.join(out_folder, stem + ".xls"))
    pdf_out   = _unique_path(os.path.join(out_folder, stem + ".pdf"))

    excel_app = None
    wb        = None
    try:
        excel_app = win32.Dispatch("Excel.Application")
        excel_app.Visible       = False
        excel_app.DisplayAlerts = False

        wb = excel_app.Workbooks.Open(cover_path)

        try:
            ws = wb.Sheets(sheet_name)
        except Exception:
            available = [wb.Sheets(i + 1).Name for i in range(wb.Sheets.Count)]
            raise ValueError(
                f"시트 '{sheet_name}'를 찾을 수 없습니다.\n"
                f"사용 가능한 시트: {available}"
            )

        # 셀 값 입력
        ws.Range(cell_map["date"]).Value      = cfg["date"]
        ws.Range(cell_map["customer"]).Value  = customer
        ws.Range(cell_map["hull_no"]).Value   = hull_no
        ws.Range(cell_map["item"]).Value      = cfg["item"]
        ws.Range(cell_map["item_code"]).Value = item_code
        try:
            ws.Range(cell_map["qty"]).Value = int(cfg["qty"])
        except (ValueError, TypeError):
            ws.Range(cell_map["qty"]).Value = cfg["qty"]

        # QR 이미지 삽입 (셀 좌상단 기준 80pt × 80pt)
        cell = ws.Range(qr_cell)
        ws.Shapes.AddPicture(
            Filename=qr_abs,
            LinkToFile=False,
            SaveWithDocument=True,
            Left=cell.Left,
            Top=cell.Top,
            Width=80,
            Height=80,
        )

        # 선택 시트만 PDF 저장
        ws.ExportAsFixedFormat(
            Type=0,
            Filename=pdf_out,
            Quality=0,
            IncludeDocProperties=True,
            IgnorePrintAreas=False,
            OpenAfterPublish=False,
        )

        # QR 포함 Excel 복사본 저장 (원본 템플릿은 수정하지 않음)
        wb.SaveCopyAs(excel_out)

    finally:
        if wb is not None:
            try:
                wb.Close(False)
            except Exception:
                pass
        if excel_app is not None:
            try:
                excel_app.Quit()
            except Exception:
                pass

    return {"excel_path": excel_out, "pdf_path": pdf_out}


# ── tkinter GUI ───────────────────────────────────────────────────────────────

class IssueCoverApp(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title("HAKQM 성적서 QR Cover 생성")
        self.resizable(False, False)

        # 마스터 데이터 모듈 함수 바인딩
        from modules.master_data_manager import (
            ensure_item_excel,
            get_customers,
            get_series_by_customer,
            get_cover_types,
            get_item_by_cover_type,
            get_next_report_id,
            update_series_hull,
        )
        self._fn_get_customers          = get_customers
        self._fn_get_series_by_customer = get_series_by_customer
        self._fn_get_cover_types        = get_cover_types
        self._fn_get_item_by_cover_type = get_item_by_cover_type
        self._fn_get_next_report_id     = get_next_report_id
        self._fn_update_series_hull     = update_series_hull

        ensure_item_excel()

        # 고객사별 시리즈 목록 캐시
        self._series_cache: dict = {}

        self._build_ui()
        self._refresh_report_id()

    def _build_ui(self):
        PAD   = {"padx": 10, "pady": 4}
        frame = tk.Frame(self, padx=16, pady=12)
        frame.pack()

        def lbl(text, row):
            tk.Label(frame, text=text, anchor="e", width=14).grid(
                row=row, column=0, sticky="e", **PAD
            )

        row = 0

        # ── 고객사 콤보박스 ──────────────────────────────────────────
        lbl("고객사", row)
        self.var_customer = tk.StringVar()
        customers = self._fn_get_customers()
        self.cmb_customer = ttk.Combobox(
            frame, textvariable=self.var_customer,
            values=customers, width=30, state="readonly"
        )
        self.cmb_customer.grid(row=row, column=1, sticky="w", **PAD)
        self.cmb_customer.bind("<<ComboboxSelected>>", self._on_customer_selected)
        row += 1

        # ── 시리즈 폴더명 콤보박스 ──────────────────────────────────
        lbl("시리즈 폴더명", row)
        self.var_series_display = tk.StringVar()
        self.cmb_series = ttk.Combobox(
            frame, textvariable=self.var_series_display,
            values=[], width=30, state="readonly"
        )
        self.cmb_series.grid(row=row, column=1, sticky="w", **PAD)
        self.cmb_series.bind("<<ComboboxSelected>>", self._on_series_selected)
        row += 1

        # ── 시리즈ID 표시창 (읽기전용) ───────────────────────────────
        lbl("시리즈ID", row)
        self.var_series_id = tk.StringVar()
        tk.Entry(
            frame, textvariable=self.var_series_id,
            width=32, state="readonly", readonlybackground="#f0f0f0"
        ).grid(row=row, column=1, sticky="w", **PAD)
        row += 1

        # ── HULL No. 입력창 ──────────────────────────────────────────
        lbl("HULL No.", row)
        self.var_hull_no = tk.StringVar()
        tk.Entry(frame, textvariable=self.var_hull_no, width=32).grid(
            row=row, column=1, sticky="w", **PAD
        )
        row += 1

        # ── 커버종류 콤보박스 ────────────────────────────────────────
        lbl("커버종류", row)
        self.var_cover_type = tk.StringVar()
        cover_types = self._fn_get_cover_types()
        self.cmb_cover = ttk.Combobox(
            frame, textvariable=self.var_cover_type,
            values=cover_types, width=30, state="readonly"
        )
        self.cmb_cover.grid(row=row, column=1, sticky="w", **PAD)
        self.cmb_cover.bind("<<ComboboxSelected>>", self._on_cover_selected)
        row += 1

        # ── ITEM 입력창 (자동 입력, 수정 가능) ──────────────────────
        lbl("ITEM", row)
        self.var_item = tk.StringVar()
        tk.Entry(frame, textvariable=self.var_item, width=32).grid(
            row=row, column=1, sticky="w", **PAD
        )
        row += 1

        # ── ITEM CODE 입력창 (자동 입력, 수정 가능) ─────────────────
        lbl("ITEM CODE", row)
        self.var_item_code = tk.StringVar()
        tk.Entry(frame, textvariable=self.var_item_code, width=32).grid(
            row=row, column=1, sticky="w", **PAD
        )
        row += 1

        # ── QTY 입력창 ──────────────────────────────────────────────
        lbl("QTY", row)
        self.var_qty = tk.StringVar(value="1")
        tk.Entry(frame, textvariable=self.var_qty, width=32).grid(
            row=row, column=1, sticky="w", **PAD
        )
        row += 1

        # ── Report ID 표시창 + 새로고침 버튼 (읽기전용) ─────────────
        lbl("Report ID", row)
        self.var_report_id = tk.StringVar()
        report_frame = tk.Frame(frame)
        report_frame.grid(row=row, column=1, sticky="w", **PAD)
        tk.Entry(
            report_frame, textvariable=self.var_report_id,
            width=26, state="readonly", readonlybackground="#f0f0f0"
        ).pack(side="left")
        tk.Button(
            report_frame, text="새로고침",
            command=self._refresh_report_id,
            font=("", 8), pady=2, padx=4
        ).pack(side="left", padx=(4, 0))
        row += 1

        # ── DATE 입력창 (오늘 날짜 기본값, 수정 가능) ───────────────
        lbl("DATE", row)
        self.var_date = tk.StringVar(value=date.today().strftime("%Y.%m.%d"))
        tk.Entry(frame, textvariable=self.var_date, width=32).grid(
            row=row, column=1, sticky="w", **PAD
        )
        row += 1

        # ── QR 위치 입력창 ───────────────────────────────────────────
        lbl("QR 위치", row)
        self.var_qr_cell = tk.StringVar(value="X5")
        tk.Entry(frame, textvariable=self.var_qr_cell, width=32).grid(
            row=row, column=1, sticky="w", **PAD
        )
        row += 1

        # ── scan_inbox 복사 체크박스 ─────────────────────────────────
        self.var_copy_inbox = tk.BooleanVar(value=True)
        tk.Checkbutton(
            frame,
            text="생성된 PDF를 01_scan_inbox에 복사",
            variable=self.var_copy_inbox,
        ).grid(row=row, column=0, columnspan=2, sticky="w", padx=10, pady=6)
        row += 1

        # ── 구분선 ──────────────────────────────────────────────────
        ttk.Separator(frame, orient="horizontal").grid(
            row=row, column=0, columnspan=2, sticky="ew", pady=6
        )
        row += 1

        # ── QR Cover 생성 버튼 ───────────────────────────────────────
        tk.Button(
            frame,
            text="  QR Cover 생성  ",
            command=self._run,
            bg="#2F5496",
            fg="white",
            font=("", 11, "bold"),
            relief="flat",
            cursor="hand2",
            pady=6,
        ).grid(row=row, column=0, columnspan=2, pady=6)

    # ── 이벤트 핸들러 ────────────────────────────────────────────────────────

    def _refresh_report_id(self):
        """issued_cover + 검사현황.xlsx 기준으로 다음 Report ID 계산"""
        try:
            self.var_report_id.set(self._fn_get_next_report_id())
        except Exception as e:
            self.var_report_id.set("HAK-TR-오류")
            messagebox.showwarning("Report ID 오류", f"Report ID 생성 실패:\n{e}")

    def _on_customer_selected(self, _event=None):
        """고객사 선택 시 해당 고객사의 시리즈 폴더명 목록을 콤보박스에 로드"""
        customer = self.var_customer.get()
        series_list = self._fn_get_series_by_customer(customer)
        self._series_cache[customer] = series_list

        displays = [s["display"] for s in series_list]
        self.cmb_series["values"] = displays
        self.var_series_display.set("")
        self.var_series_id.set("")

    def _on_series_selected(self, _event=None):
        """시리즈 폴더명 선택 시 해당 시리즈ID를 자동 입력"""
        customer = self.var_customer.get()
        display  = self.var_series_display.get()
        for s in self._series_cache.get(customer, []):
            if s["display"] == display:
                self.var_series_id.set(s["series_id"])
                break

    def _on_cover_selected(self, _event=None):
        """커버종류 선택 시 ITEM, ITEM CODE, 기본수량 자동 입력"""
        cover_type = self.var_cover_type.get()

        # 셀 매핑이 없는 커버종류 선택 시 안내
        if cover_type not in CELL_MAP:
            messagebox.showinfo(
                "알림",
                f"아직 지원하지 않는 커버 종류입니다: {cover_type}\n"
                "생성 버튼을 누르면 오류가 발생합니다."
            )

        item_info = self._fn_get_item_by_cover_type(cover_type)
        if item_info:
            self.var_item.set(item_info["item"])
            self.var_item_code.set(item_info["item_code"])
            self.var_qty.set(item_info["qty"])

    # ── 입력 검증 ────────────────────────────────────────────────────────────

    def _validate(self) -> bool:
        required = [
            ("고객사",    self.var_customer),
            ("시리즈ID",  self.var_series_id),
            ("HULL No.", self.var_hull_no),
            ("커버종류",  self.var_cover_type),
            ("ITEM",     self.var_item),
            ("ITEM CODE", self.var_item_code),
            ("QTY",      self.var_qty),
            ("Report ID", self.var_report_id),
            ("DATE",     self.var_date),
            ("QR 위치",   self.var_qr_cell),
        ]
        for label, var in required:
            if not var.get().strip():
                messagebox.showerror("입력 오류", f"[{label}] 항목을 입력해주세요.")
                return False

        cover_type = self.var_cover_type.get()
        if cover_type not in CELL_MAP:
            messagebox.showerror(
                "지원 오류",
                f"아직 지원하지 않는 커버 종류입니다: {cover_type}\n"
                "C(AHU)만 현재 지원합니다."
            )
            return False

        return True

    # ── 생성 실행 ────────────────────────────────────────────────────────────

    def _run(self):
        if not self._validate():
            return

        sheet_name    = self.var_cover_type.get()
        report_id     = self.var_report_id.get().strip()
        customer      = self.var_customer.get().strip()
        series_id     = self.var_series_id.get().strip()
        hull_no       = self.var_hull_no.get().strip()
        item_name     = self.var_item.get().strip()
        item_code     = self.var_item_code.get().strip()
        qty           = self.var_qty.get().strip()
        date_str      = self.var_date.get().strip()
        qr_cell       = self.var_qr_cell.get().strip()
        copy_to_inbox = self.var_copy_inbox.get()

        item_type = _extract_item_type(sheet_name)

        # ── 1. V3 QR 데이터 생성 ────────────────────────────────────
        qr_data = _build_qr_data_v3(
            report_id, customer, series_id, hull_no, item_type, item_code
        )

        # ── 2. QR 이미지 파일 생성 ──────────────────────────────────
        os.makedirs(TEMP_QR_DIR, exist_ok=True)
        qr_filename   = _safe_filename(f"{report_id}_{hull_no}_{item_code}_qr.png")
        qr_image_path = os.path.join(TEMP_QR_DIR, qr_filename)

        try:
            _generate_qr_image(qr_data, qr_image_path)
        except Exception as e:
            messagebox.showerror("QR 생성 오류", f"QR 이미지 생성 실패:\n{e}")
            return

        # ── 3. Excel COM Cover 생성 및 PDF 저장 ─────────────────────
        cfg = {
            "sheet_name":     sheet_name,
            "report_id":      report_id,
            "customer":       customer,
            "hull_no":        hull_no,
            "item_type":      item_type,
            "item_code":      item_code,
            "qty":            qty,
            "date":           date_str,
            "item":           item_name,
            "qr_target_cell": qr_cell,
            "qr_image_path":  qr_image_path,
        }

        result = None
        try:
            result = _create_cover(cfg)
        except Exception as e:
            messagebox.showerror("Excel/PDF 오류", f"Cover 생성 실패:\n{e}")
            return
        finally:
            try:
                if os.path.isfile(qr_image_path):
                    os.remove(qr_image_path)
            except Exception:
                pass

        # ── 4. 시리즈관리.xlsx 포함호선 업데이트 ────────────────────
        try:
            self._fn_update_series_hull(customer, series_id, hull_no)
        except Exception as e:
            messagebox.showwarning("시리즈관리 경고", f"포함호선 업데이트 실패:\n{e}")

        # ── 5. scan_inbox 복사 ───────────────────────────────────────
        inbox_msg = ""
        if copy_to_inbox:
            try:
                os.makedirs(SCAN_INBOX, exist_ok=True)
                dest = os.path.join(SCAN_INBOX, os.path.basename(result["pdf_path"]))
                shutil.copy2(result["pdf_path"], dest)
                inbox_msg = f"\n\n[scan_inbox 복사 완료]\n{dest}"
            except Exception as e:
                inbox_msg = f"\n\n[scan_inbox 복사 실패]\n{e}"

        # ── 6. 완료 메시지 표시 ──────────────────────────────────────
        messagebox.showinfo(
            "완료",
            f"QR Cover 생성 완료!\n\n"
            f"[PDF]\n{result['pdf_path']}\n\n"
            f"[Excel]\n{result['excel_path']}"
            f"{inbox_msg}"
        )

        # 다음 생성을 위해 Report ID 갱신
        self._refresh_report_id()


if __name__ == "__main__":
    app = IssueCoverApp()
    app.mainloop()
