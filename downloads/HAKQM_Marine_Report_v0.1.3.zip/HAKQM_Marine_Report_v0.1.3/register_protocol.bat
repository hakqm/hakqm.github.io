@echo off
chcp 65001 >nul

echo [HAKQM] Register custom protocols
echo Base: %~dp0
echo.

if not exist "%~dp0run_cover_hidden.vbs" (
    echo [ERROR] Missing file: %~dp0run_cover_hidden.vbs
    pause
    exit /b 1
)

if not exist "%~dp0run_sort_hidden.vbs" (
    echo [ERROR] Missing file: %~dp0run_sort_hidden.vbs
    pause
    exit /b 1
)

if not exist "%~dp0run_check_hidden.vbs" (
    echo [ERROR] Missing file: %~dp0run_check_hidden.vbs
    pause
    exit /b 1
)

reg delete "HKCU\Software\Classes\hakqm-cover" /f >nul 2>nul
reg delete "HKCU\Software\Classes\hakqm-sort" /f >nul 2>nul
reg delete "HKCU\Software\Classes\hakqm-check" /f >nul 2>nul

reg add "HKCU\Software\Classes\hakqm-cover" /ve /d "URL:HAKQM Cover" /f
reg add "HKCU\Software\Classes\hakqm-cover" /v "URL Protocol" /t REG_SZ /d "" /f
reg add "HKCU\Software\Classes\hakqm-cover\shell\open\command" /ve /d "\"%SystemRoot%\System32\wscript.exe\" \"%~dp0run_cover_hidden.vbs\"" /f

reg add "HKCU\Software\Classes\hakqm-sort" /ve /d "URL:HAKQM Sort" /f
reg add "HKCU\Software\Classes\hakqm-sort" /v "URL Protocol" /t REG_SZ /d "" /f
reg add "HKCU\Software\Classes\hakqm-sort\shell\open\command" /ve /d "\"%SystemRoot%\System32\wscript.exe\" \"%~dp0run_sort_hidden.vbs\"" /f

reg add "HKCU\Software\Classes\hakqm-check" /ve /d "URL:HAKQM Check" /f
reg add "HKCU\Software\Classes\hakqm-check" /v "URL Protocol" /t REG_SZ /d "" /f
reg add "HKCU\Software\Classes\hakqm-check\shell\open\command" /ve /d "\"%SystemRoot%\System32\wscript.exe\" \"%~dp0run_check_hidden.vbs\"" /f

echo.
echo [OK] HAKQM custom protocols registered.
echo If you move this folder, run this file again.
echo.
pause